    #!/usr/bin/env python3
import os.path
import numpy as np
import matplotlib.pyplot as plt
import random
import datetime
from operator import itemgetter
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.utils import resample  # for function next_sample of class Al
from sklearn.gaussian_process import GaussianProcessRegressor # for the inherited class
from sklearn.gaussian_process.kernels import Matern, RBF, ConstantKernel, WhiteKernel
from scipy.stats import dirichlet, norm
from sklearn.gaussian_process import GaussianProcessRegressor as GPR
import warnings
warnings.filterwarnings("ignore") # Ignore all warnings


class Al:
    '''
    NOTE: "Al" = "Active learning"
    Active Learning class that is able to:
    i) reduce the number of samples in a dataset by choosing the best ones.
    ii) show the evolution of MAE as a function of the number of samples inserted
    iii) suggest the next virtual sample (or "virtual experiment") to be added to an existing dataset

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%% HOW TO USE IT %%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Example 1:  taking the best 3 virtual samples out of 1000 and specifying ranges for each feature

    >>> import numpy as np
    >>> import sys
    >>> sys.path.insert(0,"/home/rodrigo/Dropbox/dados/ubt/backup_UBT/utilities_dropbox")
    >>> from ml_applications import Al
    >>> x = np.array([[1,2,3],[3,2,4],[6,3,2],[5,7,9]])
    >>> y = np.array([1.4,2.3,3.1,2.9]).reshape(4,1) # Note: y needs to be a 2D array!
    >>> model = Al(x,y)
    >>> model.next_sample(n_max = 1000, n_best=3, ranges = [[1,6],[2,7],[2,9]])
    >>> model.best_samples
    array([[3.47784439, 2.40913164, 7.63768904],
           [4.19815461, 2.02269984, 7.22466806],
           [3.20252405, 2.28552977, 7.58213541]])
    >>> model.best_indices
    [223, 376, 229]
    >>> model.best_stds
    array([0.33361655, 0.33361655, 0.31269154])

    '''

    def __init__(self, x, y):
        '''
        x and y are arrays:
        x = features (2D array with one or more columns)
        y = target (2D array with one column, dimension is (n_samples,1)). TODO: expand to many targets!
        '''
        self.features = x
        self.target = y
        self.features_shape = self.features.shape
        self.target_shape = self.target.shape
        self.full_dataset = np.c_[x, y]
        if len(self.target_shape) == 1:
            self.n_targets = 1
        else:
            self.n_targets = self.target.shape[1]

    def next_sample(self, n_max=1000000, n_best=10, ranges='auto', n_subsets=10,
                    bootstrap_size=None, method='rf', virtual_features=False,
                    starting_dataset=False, n_estimators_rf=None, kernel_krr=None,
                    kernel_svr=None, gamma_krr=None, alpha_krr=None, alpha_lasso=None,
                    n_neighbors_knn=None, loss_gbr=None, learning_rate_gbr=None,
                    c_svr=None, epsilon_svr=None, n_estimators_xgbr=None,
                    eta_xgbr=None, normalize_sample_vectors=False,
                    virtual_gauss_norm=False, scale_dataset=True, sigma_f_gpr=None,
                    l_gpr=None, random_state_gbr = None):
        '''
        This function subdivides the input dataset into "n_subsets" subsets via bootstrapping (without replacement), each
        subset having "bootstrap_size" samples, then trains "n_subsets" different models (one for each subset, ML method
        = "method") and do "n_subsets" predictions using each of the "n_max" generated virtual samples (each of them
        defined in the range given in "ranges"). The predictions done for each virtual sample are used to calculate
        std() and this function finally outputs the virtual samples with the "n_best" largest standard deviations of the
        predictions.

        The parameter "ranges" is a list with lowest and highest variations of each feature. E.g. for 3 different features:
        ranges = [[0.1,0.9], [20,50], [-3,-1]]. If ranges is 'normalized', it is assumed that the range of each feature
        is limited to [0,1]. If ranges is 'auto', automatic ranges of the virtual samples are assigned to each feature
        based on the maximum and minimum values found in the provided (x,y) dataset.

        The parameter virtual_gauss_norm requests that virtual points are generated from a multivariate gaussian distribution
        with every feature having mean = 0.5 (good for compositions) and covariance = identity matrix.

        Parameter "normalize_sample_vector" normalizes each virtual sample individually, so that the sum of all features
        in each sample is 1. The next sample found via the function next_sample() is therefore normalized.

        If the active learning procedure should be done using customized starting features/target dataset and
        the virtual features, then both parameters "virtual_features" and "starting_dataset" need to be given.
        In this case, the starting features/target (=2D array, last column = target) are provided as
        argument of "starting_dataset" and the pool of extra (virtual) features (no target!) is provided via "virtual_features"
        as a 2D array. The parameter "n_max" is therefore ignored.

        scale_dataset uses StandardScaler() fitted with the training set and apply the learned scaling in the test set. If
        you are using scaled datasets e.g. compositions, where the training and test set were drawn from the same pool
        of samples (all features have the same unit!), just use "scale_dataset=False".

        How to use:

        To provide ranges for each of the 7 features, using 1000 virtual samples 
        and getting the best 10 samples (= largest uncertainty in the predictions) 
        and using Kernel Ridge:
        
        >>> ranges = [[0,1],[0,1],[0,1],[0,1],[0,1],[0,1],[0,1]]
        >>> model = Al(X, y)
        >>> model.next_sample(method='krr', n_max = 1000, n_best=10, ranges=ranges)

        Check the results:
        >>> model.best_samples
        >>> model.best_stds
        >>> model.best_indices
        '''

        n_features = self.features_shape[1]
        n_samples = self.features_shape[0]

        # Use randomly generated virtual points?
        if not virtual_features.any() and not starting_dataset.any():
            if bootstrap_size == None:
                bootstrap_size = int(n_samples * 0.7)
            dataset = self.full_dataset
        else:
            if bootstrap_size == None:
                bootstrap_size = int(starting_dataset.shape[0] * 0.7)
            dataset = starting_dataset

        # ranges
        if ranges == 'normalized':  # normalized ranges are chosen
            ranges = []
            for i in range(n_features):
                ranges.append([0, 1])
        elif ranges == 'auto':  # automatic ranges will be computed
            ranges = []
            X = self.features
            for i in range(n_features):
                low = np.min(X[:, i])
                high = np.max(X[:, i])
                ranges.append([low, high])

        # 1) bootstraping x and y
        bootstrap_data = []  # list to keep all bootstrap samples (each as a different array)
        for i in range(n_subsets):
            bootstrap_data.append(resample(dataset, replace=False, n_samples=bootstrap_size))

        # 2) generating the virtual samples (or not)
        if not virtual_features.any() and not starting_dataset.any():  # create virtual samples
            virtual_points = []
            if virtual_gauss_norm:  # virtual points will be drawn from a multivariate gaussian distribution
                media = [0.0 for item in range(len(ranges))]  # for compositions, media = 0.5
                virtual_points = np.random.multivariate_normal(media, np.identity(7), size=(n_max))
            else:
                for i in range(n_max):
                    line = []
                    for pair in ranges:
                        low = pair[0]
                        high = pair[1]
                        feature = random.uniform(low, high)
                        line.append(feature)
                    virtual_points.append(line)
                virtual_points = np.array(virtual_points).reshape(n_max, len(ranges))

            if normalize_sample_vectors:  # TODO: use dirichlet! normalized vectors
                virtual_points = virtual_points / (np.sum(virtual_points, axis=1).reshape(n_max, 1))

        else:
            virtual_points = virtual_features
            n_max = virtual_points.shape[0]

        # 3) training one model per bootstrap dataset and performing predictions on virtual points
        predictions = np.empty((n_max, n_subsets))
        for i, data in enumerate(bootstrap_data):  # each "data" is a 2D array with features

            ###################
            # choosing the method
            if method == 'rf':
                if n_estimators_rf != None:
                    model = RandomForestRegressor(n_estimators=n_estimators_rf, n_jobs=-1)
                else:  # default hyperparameters
                    model = RandomForestRegressor(n_estimators=100, n_jobs=-1)

            elif method == 'krr':
                if kernel_krr == None and gamma_krr == None and alpha_krr == None:
                    model = KernelRidge(kernel='rbf', gamma=0.001, alpha=0.001)
                else:
                    model = KernelRidge(kernel=kernel_krr, gamma=gamma_krr, alpha=alpha_krr)

            elif method == 'xgbr':
                if n_estimators_xgbr == None and eta_xgbr == None:
                    model = XGBRegressor()
                else:
                    model = XGBRegressor(n_estimators=n_estimators_xgbr, eta=eta_xgbr)

            elif method == 'knn':
                if n_neighbors_knn == None:
                    model = KNeighborsRegressor(n_jobs=-1)  # default = 1 neighbor
                else:
                    model = KNeighborsRegressor(n_neighbors=n_neighbors_knn, n_jobs=-1)

            elif method == 'lasso':
                if alpha_lasso == None:
                    model = Lasso(alpha=0.1, max_iter=100000)
                else:
                    model = Lasso(alpha=alpha_lasso, max_iter=100000)

            elif method == 'lr':
                model = LinearRegression()

            elif method == 'gbr':
                if loss_gbr == None and learning_rate_gbr == None and random_state_gbr == None:
                    model = GradientBoostingRegressor()
                else:
                    model = GradientBoostingRegressor(loss=loss_gbr, learning_rate=learning_rate_gbr,
                                                      random_state=random_state_gbr)

            elif method == 'svr':
                if kernel_svr == None and c_svr == None and epsilon_svr == None:
                    model = SVR()
                else:
                    model = SVR(kernel=kernel_svr, C=c_svr, epsilon=epsilon_svr)
            ###################
            # preprocessing
            if scale_dataset:
                scalerx = StandardScaler()
                scalery = StandardScaler()
                X_train = scalerx.fit_transform(data[:, :-1])  # TODO: only 1 target property is used!
                y_train = scalery.fit_transform(
                    data[:, -1].reshape(-1, 1)).ravel()  # TODO: only 1 target property is used!
                X_test = scalerx.transform(virtual_points)
            else:
                X_train = data[:, :-1]  # TODO: only 1 target property is used!
                y_train = data[:, -1]  # TODO: only 1 target property is used!
                X_test = virtual_points

            # training and prediction
            model.fit(X_train, y_train)
            pred = model.predict(X_test)
            predictions[:, i] = pred

        std_devs = np.std(predictions, axis=1)  # std of each row

        # 4) order stds and get index mask and stds
        std_indices = [[index, std] for index, std in
                       zip(range(n_max), std_devs)]  # list: [[0,std0],[1,std1],[2,std2]...]
        std_indices_ordered = sorted(std_indices, key=itemgetter(1), reverse=True)
        std_indices_ordered = np.array(std_indices_ordered)
        best_stds = std_indices_ordered[:n_best, 1]
        best_indices = [int(index) for index in std_indices_ordered[:n_best, 0]]
        mask_indices = [True if index in best_indices else False for index in range(n_max)]

        # 5) organize results and new attributes
        best_samples = virtual_points[mask_indices]
        self.best_samples = best_samples
        self.best_stds = best_stds
        self.best_indices = best_indices

    def next_internal_sample(self, method="rf", n_start=10, n_max_growth=20, n_best=2, n_trials=5):
        '''
        Evaluate the active learning procedure that uses only samples of the dataset (x,y) provided when creating the
        object of class Al(). Initially, "n_start" samples from the total number of samples will be taken and one active
        learning cycle will be done (via function next_sample() and using "method"), where the "n_best" samples with the
        largest standard deviations wil be used to grow the initial dataset. This is repeated until the dataset has
        reached "n_max_growth" samples. In order to generate standard deviations (and improve statistics), the whole
        procedure is repeated "n_trials" times and the corresponding results are finally averaged.
        E.g. MAE(10 samples) = 3.5 +/- 0.6 => active learning cycle 1 => MAE(12 samples) = 3.2 +/- 0.5 => etc...

        NOTE: how to call methods of other classes while inside the current class:
        class Ml:
            def leave1out(self, a, b):
                return a + b

        class Al:
            def sum_f(self, a, b, c):
                return Ml().leave1out(a, b) + c

        '''
        #                         trial 1                 trial 2                   trial "n_trials"
        mae_active = []  # [[MAE10,MAE12,...,MAE20],[MAE10,MAE12,...,MAE20],..., [MAE10,MAE12,...,MAE20]]
        mae_random = []  # [[MAE10,MAE12,...,MAE20],[MAE10,MAE12,...,MAE20],..., [MAE10,MAE12,...,MAE20]]
        n_active_cycles = (n_max_growth - n_start) // n_best
        for i in range(n_trials):
            # get subsample of the full_dataset
            dataset = resample(self.full_dataset, replace=False, n_samples=n_start)
            unselected_dataset = None  # TODO: get the rest of the unselected samples for the remaining active learning cycles!!
            current_features = dataset[:, :-1]  # TODO. only 1 target property is assumed! expand it!
            current_target = dataset[:, -1]  # TODO. only 1 target property is assumed! expand it!
            mae_active_temp = []
            mae_random_temp = []
            for j in range(n_active_cycles):
                # active learning part
                # 1) apply next_sample() to get next samples (TODO: add parameter "internal_samples = None" to next_sample())
                # self.next_sample(internal_data = True, n_best = n_best, ranges=None, n_subsets = 10, bootstrap_size = None, method='rf')
                # 2) grow the dataset
                # 3) calculate MAE via leave1out
                # 4) append MAE to mae_active_temp = [MAE10,MAE12,MAE14,...,MAE20]

                # baseline control
                # a) randomly select any "n_best" samples
                # b) add the new samples to the current subset
                # c) calculate MAE via leave1out
                # d) append MAE to mae_random_temp = [MAE10,MAE12,MAE14,...,MAE20]
                pass
            # append mae_active_temp to mae_active and mae_random_temp to mae_random
            pass
        # average the numbers in mae_active and mae_random
        # plot the results (average MAE x number of samples of the subset for active learning and random treatments


class Bo:
    """
    Bayesian optimizer based on a manual implementation and on the modAL library. Some useful functions to generate virtual
    samples (discretized or not, for formulations or processes) as well as to generate vector discretizations are also
    available.

    How to use it:
    >>> import sys
    >>> sys.path.insert(0,"/home/rodrigo/Dropbox/scripts/ml_applications")
    >>> from ml_applications import Bo
    >>> bo = Bo()

    # Calculate discretizations for two features (10 points for the first feature, 30 for the second)
    >>> discr = bo.calc_discretization(ranges_real = [[2,5], [20,80]], n_points_discretization= [10,30])

    # Use 'discr' to generate virtual samples for general parameters (no compositions). Histograms are also shown.
    >>> X_virtual = bo.generate_virtual(n_samples=1000, for_composition=False, n_vars=2, discretization=discr)

    # NOTE: If you are NOT doing compositions, replacing the two last functions by self.generate_2D_arrays() is
    #       MUCH more efficient. Below, the real values of (start,end,increment) are given for each parameter.
    #       Note that X_virtual is fractionary.
    >>> X_virtual = generate_2d_array(n = 1000, ranges_discretization = [(2, 5, 0.1), (20, 80, 1)])

    # Select three random samples from X_virtual
    >>> samples = bo.get_random_samples(X_virtual, 3)

    # Convert the fractionary array 'samples' to real values of the properties (for the opposite, use 'frac2real=False')
    >>> samples_real = bo.convert_features(features = samples, ranges_real = [[2,5], [20,80]])

    # Suggest samples having maximum target properties (default) from the Bayesian Optimization procedure
    >>> _ = bo.(X_virtual, features, target)

    # Note that sometimes a great boost in the efficiency of the BO search is achieved by using only the largest
    # or lowest target properties. To select the samples with the three largest targets to redo the BO, just do
    # (here adding explicitly the maximize parameter and the kernel)
    >>> newfeatures, newtarget = bo.select_best_targets(features, target, n_samples=3, get_maximum=True)
    >>> _ = bo.(X_virtual, newfeatures, newtarget, maximize=True, mykernel='matern')

    # Update dataset (features, targets or both), or create them if they do not exist. Below, we use the array 'samples'
    >>> bo.grow_dataset(old_features_filename='features.npy', new_features_array = samples)
    """

    def check_duplicates(self, samples_to_test, features_file = 'features.npy', decimals_to_round = 3):
        '''
        Check that the row(s) of the (1D or 2D) array 'samples_to_test' are not inside
        the current 2D array 'features'. Floats are rounded to 'decimals_to_round' before
        samples are compared. If any samples are repeated inside features, a message will be printed
        on the screen.

        How to use it:

        >>> samples = np.array([[1,2,3],[4,5,6]])
        >>> bo.check_duplicates(samples)
        '''
        # import and round the main features
        features = np.load(features_file)
        features = np.round(features, decimals_to_round)

        # check the samples_to_test and round it
        if samples_to_test.ndim == 1:
            samples_to_test = samples_to_test.reshape(1,-1) # 2D array with one single "row" vector
        samples_to_test = np.round(samples_to_test, decimals_to_round)
        
        # compare samples
        features_list = [tuple(item) for item in features] # list of tuples of floats with 'decimals_to_round' decimals 
        found_duplicates = False
        for i, sample in enumerate(samples_to_test):
            sample = tuple(sample)
            if sample in features_list:
                print(f'!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
                print(f'Sample {i} {sample} is ALREADY in features!')
                print(f'!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!')
                found_duplicates = True
        if not found_duplicates:
            print(f'\nNormal termination:\nNo duplicates of the suggested samples were found in file {features_file}\n')


    def select_best_targets(self, features, target, n_samples=5, get_maximum=True):
        '''
        Selects a specified number of samples based on target values from a 2D array of features
        and a 1D array of targets.

        Parameters:
        - features (numpy.ndarray): A 2D array where each row represents a sample, and each column represents a feature.
        - target (numpy.ndarray): A 1D array containing target values corresponding to the samples in the 'features' array.
        - n_samples (int): The number of samples to select.
        - get_maximum (bool, optional): If True, selects the 'n' samples with the highest target values;
                                         if False, selects the 'n' samples with the lowest target values.
                                         Defaults to True.

        Returns:
        - selected_samples (numpy.ndarray): A 2D array containing the selected samples based on the specified criteria.
        - selected_target (numpy.ndarray): A 1D array containing the corresponding target values for the selected samples.

        Raises:
        - ValueError: If the number of samples in 'features' and 'target' arrays are not equal or if 'target' has
          more than one column (only 1 target is allowed)

        Example (select the two largest targets):
        >>> features = np.array([[1, 2], [3, 4], [5, 6], [7, 8]])
        >>> target = np.array([10, 5, 20, 15])
        >>> n = 2
        >>> selected_samples, selected_target = select_samples(features, target, n, get_maximum=True)

        Note:
        The function sorts the combined array of features and targets based on target values and then selects the
        top or bottom 'n' samples, depending on the value of 'get_maximum'. It ensures that the number of
        samples in 'features' and 'target' arrays is equal.

        '''
        # Check if the input arrays have the same number of samples
        if len(features) != len(target) or target.ndim > 1:
            raise ValueError(
                "Number of samples in features and target arrays must be the same. Only one target is allowed")

        # Combine features and target into a single array for sorting
        combined_data = np.c_[features, target.reshape(-1, 1)]

        # Sort the combined array based on the target column
        sorted_data = combined_data[combined_data[:, -1].argsort()]

        # Get the indices of the selected samples
        if get_maximum:
            selected_features = sorted_data[-n_samples:, :-1]
            selected_targets = sorted_data[-n_samples:, -1]
        else:
            selected_features = sorted_data[:n_samples, :-1]
            selected_targets = sorted_data[:n_samples, -1]

        return selected_features, selected_targets


    def convert_features(self, features = None, ranges_real = None, frac2real=True):
        """
        Given the features array (2D array 'X') and the real valued 'ranges' for the properties (or features) shown in each
        column, convert fractionary features into real-valued features and vice-versa.
        'ranges_real' = list of sub-lists of floats or integers (e.g., [[10,20], [25.3,75.4], [-1,3]]) with the lowest and
        highest values of the real properties.
        """
        # initial processing
        lows = [item[0] for item in ranges_real]
        lows = np.array(lows).reshape(1, len(ranges_real))
        deltas = [item[1] - item[0] for item in ranges_real]
        deltas = np.array(deltas).reshape(1, len(ranges_real))

        # conversion
        if frac2real:
            features_real = (features * deltas) + lows
            return features_real
        else:
            features_frac = (features - lows) / deltas
            return features_frac


    def calc_discretization(self, ranges_real = None, discretization_real = None, n_points_discretization = None, silence=False):
        """
        For the sake of discretizing the virtual samples, the final discretization list used
        as argument in the function 'self.generate_virtual()' is calculated here.

        ranges_real is a list of sublists of the form [low,high] (int or float), containing
        the ranges of each variable (in real units, not fractionary, unless features are compositions!)

        discretization_real (int or float) is the distance between adjacent points in the grid (in real units). This
        is a list of sublists, each with [low,high] real ranges (see below)

        n_points_discretization is one single integer OR a list of integers providing the total number of points of
        discretization for each feature, where the given initial and final points of the ranges are included.
        If n_points_discretization is given, the parameter 'discretization_real' is ignored.

        Examples:         pressure/bar  temperature/C   time/min
           ranges_real = [[75.0,180.0],  [35.0,110.0], [2.5,30.0]]
           discretization_real = [5.0, 2.5, 2.5]
           Above, the pressure can have the values 75, 80, 85, ..., 180, while time can
           assume the values 2.5, 5.0, 7.5, ..., 30.0, and so on.

        Return: list with discretizations for normalized variables (e.g., [0.01, 0.05, 0.066])
        """
        # set priorities in case discretization_real and n_points_discretization are provided
        if n_points_discretization and discretization_real:
            print('You can only provide n_points_discretization OR discretization_real. Aborting calc_discretization()...')
            return 'aborting'

        if not n_points_discretization: # here, use discretization_real
            discretizations = []
            points_per_var = []
            for i, (myrange, mydiscr) in enumerate(zip(ranges_real, discretization_real)):
                discr = 1 / ((myrange[1] - myrange[0]) / mydiscr)
                discretizations.append(discr)
                n_points = 1 + (myrange[1] - myrange[0]) / mydiscr
                points_per_var.append(n_points)
        else: # n_points_discretization was provided (as integer or list of integers)
            discretizations = []
            if type(n_points_discretization) == int:
                points_per_var = [n_points_discretization for item in ranges_real]
            elif type(n_points_discretization) == list:
                points_per_var = n_points_discretization # for factorial calculation below

            for mypoints in points_per_var:
                discr = 1 / (mypoints - 1)
                discretizations.append(discr)

        # Total number of combinations of variables inside X_virtual according
        # to the ranges & discretizations given
        factorial = 1
        for number in points_per_var:
            factorial *= number
        if not silence:
            print(f'{int(factorial)} different combinations of variables are possible for your virtual dataset.')
            print("This information is useful to find n_samples for 'self.generate_virtual()'.")

        return discretizations


    def generate_virtual(self, n_samples=None, n_vars=None, for_composition=True, discretization=None, silence = False):
        """
        Generate 'n_samples' virtual samples (as rows, features in the columns) for use in Bayesian Optimization approaches.
        If 'for_composition' is True, the sum of the components of each vector (or sample) is unity.
        n_vars = number of features (or variables), as columns.

        If discretization is used (= list of floats), the components of each vector become
        multiple of the 'discretization' argument. Discretizing might prevent successive BO steps from becoming
        stuck in the same (potentially local) maximum/minimum. Discretizations can be easily calculated via the
        function 'self.calc_discretizations()'.

        Return: 2D array (floats) with shape (n_samples, n_vars)
        """
        if for_composition:
            if discretization:
                print('ERROR: Compositions were requested, but discretization was also provided\nHere, composition vectors cannot be discretized. Aborting generate_virtual()...')
                return 'aborting'
            else: # normal, non-discretized composition vectors
                alpha = [1 / n_vars for i in range(n_vars)]  # how often each variable appears in the distribution
                X = dirichlet.rvs(alpha=alpha, size=n_samples)

        else:  # processing parameters or other (discretizable) variables

            X = np.random.rand(n_samples, n_vars)
            if discretization:
                base_list = []
                for i in range(len(discretization)):
                    sub_base_list = np.linspace(0, 1, num=int(1 / discretization[i]) + 1)
                    base_list.append(sub_base_list)

                samples = []
                for i in range(n_samples):
                    sample = []
                    for j in range(len(discretization)):  # iterates over sub-lists of elements
                        size = len(base_list[j])
                        index = np.random.randint(low=0, high=size)
                        feature = base_list[j][index]
                        sample.append(feature)
                    samples.append(sample)
                X = np.array(samples).reshape(-1, len(discretization))

        X = np.round(X, decimals=4)
        # remove duplicates that discretization generates
        if discretization:
            new = []
            Xlist = X.tolist()
            for item in Xlist:
                if item not in new:
                    new.append(item)
            X = np.array(new)

        if not silence:
            # check statistics on the screen
            self.check_virtual(X)

        return X


    def check_virtual(self, features = None):
        """
        Check the statistics (histogram) of the features (X_virtual generated via 'generate_virtual')
        """
        plt.figure(figsize = (10,10))
        for i in range(features.shape[1]):
            plt.subplot(3,3,i+1)
            plt.hist(features[:,i], bins = 50)
            plt.xlabel(f'Feature {i}')
            plt.ylabel('Counts')
        plt.tight_layout()


    def get_random_samples(self, features = None, n_samples = None):
        """
        Randomly select 'n_samples' samples from the features array
        """
        indices = np.arange(0, features.shape[0])
        chosen_indices = np.random.choice(indices, size = n_samples)
        random_selection = features[chosen_indices]
        return random_selection


    def grow_dataset(self, old_features_filename = None, new_features_array = None, old_target_filename = None, new_target_array = None, silence=False):
        """
        Update the dataset with new features and new targets (both should be 2D arrays!).
        The files are numpy files (extension .npy).

        IMPORTANT: if another file already exists with the same name and it has appropriate shape to be concatenated with the
        new_features_array (or new_target_array), this will be done, even if the 'old_features_filename' has nothing to
        do with the new_features_array.

        The old files are saved again in the current folder as a backup and have the following format:
         old_filename_YYYYMMDD_hhmmss_XSamples.npy, where date/time tags + number of samples (=X) were added.

        Returns: report shown on the screen about the last added samples
        """
        if old_features_filename and new_features_array.any():

            if os.path.isfile(old_features_filename):
                current_features = np.load(old_features_filename)
                features = np.r_[current_features, new_features_array]
                n_added = current_features.shape[0]

                # backup old features
                timenow = datetime.datetime.now()
                tag = timenow.strftime("%Y%m%d_%H%M%S")
                np.save(f'{old_features_filename}_{tag}_{n_added}Samples', current_features)

                # save new features (overwrite old ones)
                np.save(old_features_filename, features)

                # get report
                if not silence:
                    temp = np.load(old_features_filename)
                    if type(new_features_array) == np.ndarray:
                        print(f'{new_features_array.shape[0]} new sample(s) was/were added to the features. The new (already updated) features array is:\n')
                    else:
                        print(f'One new sample was added to the features. The new (already updated) features array is:\n')
                    print(temp)
            else: # the features file needs to be created
                np.save(old_features_filename, new_features_array)
                print(f'File {old_features_filename} was just created!')


        if old_target_filename and new_target_array.any():

            if os.path.isfile(old_target_filename):
                current_target = np.load(old_target_filename)
                target = np.r_[current_target, new_target_array]
                n_added = current_target.shape[0]

                # backup old target
                timenow = datetime.datetime.now()
                tag = timenow.strftime("%Y%m%d_%H%M%S")
                np.save(f'{old_target_filename}_{tag}_{n_added}Samples', current_target)

                # save new features (overwrite old ones)
                np.save(old_target_filename, target)

                # get report
                if not silence:
                    temp = np.load(old_target_filename)
                    if type(new_features_array) == np.ndarray:
                        print(f'{new_target_array.shape[0]} new sample(s) was/were added to the target. The new (already updated) target array is:\n')
                    else:
                        print(f'One new sample was added to the target. The new (already updated) target array is:\n')
                    print(temp)
            else: # the target file needs to be created
                np.save(old_target_filename, new_target_array)
                print(f'File {old_target_filename} was just created!')


    def bayes_opt(self, X_virtual, features, target, maximize=True, use_best_n=False, qsi=0.02, exp_is_noisy=False, mykernel='rbf',
                  scale_features = True, silence=False):
        """
        Use Bayesian OPT and Gaussian processes with the expected improvement as acquisition function
        (default qsi = 0.02) to suggest a sample from X_virtual with maximum (or minimum) target. It is assumed that the
        features were extracted originally from X_virtual (they have the same scale!).

        If the targets are heterogeneous, one can alternatively specify 'use_best_n' samples (integer) to be used in the
        BO: if a minimization is performed, the samples with 'use_best_n' lowest targets are selected,
        otherwise the samples with 'use_best_n' largest targets are used.

        If the data of the experiment (features, target) seems to be noise, use "exp_is_noisy = True" ( f(x+) in the
        MANUAL aquisition functionn changes accordingly (not for modAL).

        The argument of 'mykernel' can be 'rbf' (default) or 'matern'.

        Returns:
            A full report is printed on the screen with samples and corresponding GP predictions (unless silence is True)
            sample 1 (calculated using the manual model)
            sample 2 (randomly-drawn sample to increase diversity)
            sample 3 (RF-based active learning prrocedure)
            sample 4 (100% exploitation - greedy procedure)


        HOW TO USE:

        # Make BO to suggest new samples using BO/AL/Random/Greedy (all returned variables are in "_")
        # The command below also prints a big report on the screen
        >>> _ = self.bayes_opt(X_virtual, features, target)

        # To get the samples very precisely (and not seeing on the screen the report), just do:

        >>> manual, modal, random, al, greedy = self.bayes_opt(X_virtual, features, target, silence = True)

        # Update the features and target .npy files with new data from arrays "new_features" and "new_targets"
        # Note: the old version of features and target .npy files will be backedup with info tags and the current
        # files will be overwritten with new content.
        >>> bo.grow_dataset(old_features_filename='features.npy', new_features_array=new_features)
        >>> bo.grow_dataset(old_target_filename='target.npy', new_target_array=new_targets)

        # Combine the two previous commands:
        >>> bo.grow_dataset(old_features_filename='features.npy', \\
                            new_features_array=new_features,       \\
                            old_target_filename='target.npy',       \\
                            new_target_array=new_targets)
        """
        # Security checks
        if features.shape[0] != target.shape[0]:
            print('Your features and target arrays have different number of samples! Aborting bayes_opt()...')
            return

        # backup the full dataset for more precise predictions
        features_full = features.copy() # save full dataset for better predictions on the BO suggested samples
        target_full = target.copy() # save full dataset for better predictions on the BO suggested samples
        
        # Select best samples?
        if use_best_n:
            features, target = self.select_best_targets(features, target, n_samples=use_best_n, get_maximum=maximize)

        ## TODO: further possibilities

        # i) select a random number of samples to use as arrays 'features'/'target' instead of ALL samples

        # ii) randomly select the samples using a metropolis algorithm. The target values of array 'target' are first
        # converted to the range [0,1], then a random number 'R' in the range [0,1] is drawn. If maximize=True, an speciic
        # sample is included/selected to integrate the new 'features'/'target' arrays if and only if R < normalized target
        # value for that sample (and vice versa if maximize=False). In this way, samples with high target properties are
        # preferred.

        # iii) In the same 'if statement' of ii) above with the metropolis condition, one must also check that the selected sample
        # is not too close from another one already selected for the new features/target arrays. The similarity check will
        # be done using a normalized kernel (e.g., if kernel of current sample is within 1% of the kernel of any of the
        # already-selected samples, do not select the current kernel).

        # iv) Rearrange the BO() test (see cells below) inside a for loop to check the average number of draws needed to maximize the
        # property up to e.g. 95% of the maximum achievable value. In this way, each hyperparameter used inside BO() would
        # show an exact (metrics) performance with average and standard deviation. This would show if the metropolis
        # approach described above is indeed better than no metropolis...

        ###################################
        ####### INTERNAL FUNCTIONS ########
        ###################################

        def clean_array(A, B):
            """
            Remove all rows of array B from array A. Return the clean version of array A
            """
            A = A.tolist()
            B = B.tolist()
            clean_A = []
            for row in A:
                if row not in B:
                    clean_A.append(row)
            clean_A = np.array(clean_A)
            return clean_A

        def ei(gpr, X_virtual, X, Y, qsi=0.02, maximize=maximize, exp_is_noisy=exp_is_noisy, scale_features=scale_features):
            '''
            Calculates the expected improvement (utility) for
            all samples (features) of X_virtual. The known (current)
            dataset is described by X and Y. Larger qsi means
            more exploration, smaller qsi means more exploitation.
            gpr = Gaussian processes object.
            The current dataset samples (X) are assumed to
            have been drawn from the large X_virtual, so that pre-
            processing the features (train => test) is not needed.
            Returns: The utility for all samples in X_virtual
            '''
            if not maximize:  # target must be minimized
                Y = -Y
            ndim = X_virtual.ndim  # 1D or 2D?
            if ndim == 1:
                X = X.reshape(-1, 1)  # 1 feature only
                X_virtual = X_virtual.reshape(-1, 1)
                Y = Y.reshape(-1, 1)

            gpr.fit(X, Y)
            mu, sigma = gpr.predict(X_virtual, return_std=True)
            sigma = sigma #.reshape(-1, 1) # debug
            mu_dataset = gpr.predict(X)  # predictions are y-scaled
            #print(f'X.shape = {X.shape}, Y.shape = {Y.shape}, sigma.shape = {sigma.shape}, X_virtual.shape = {X_virtual.shape}') # debug

            if exp_is_noisy:
                fxplus = np.max(Y)  # if experimental data is noisy
            else:
                fxplus = np.max(mu_dataset)  # f(x+)

            a = mu - fxplus - qsi
            #print(f'a.shape = {a.shape}') # debug
            sigma = sigma + 1e-10  # add a small value to array sigma to avoid dividing by zero errors
            #sigma = sigma.reshape(-1) # debug
            #print(f'sigma.shape = {sigma.shape}')  # debug
            Z = a / sigma # here, sigma will never be zero. # Z is 30x30 (for 30 samples in X_virtual)
            #print(f'Z.shape = {Z.shape}') # debug
            ei = a * norm.cdf(Z) + sigma * norm.pdf(Z)
            #print(f'ei.shape = {ei.shape}')#, sigma.shape = {sigma.shape}, a.shape = {a.shape}, Z.shape = {Z.shape},'
                  #f'norm.cdf(Z).shape = {norm.cdf(Z).shape}, a*norm.cdf(Z).shape = {a*norm.cdf(Z).shape},'
                  #f'norm.pdf(Z).shape = {norm.pdf(Z).shape}, sigma*norm.pdf(Z).shape = {sigma*norm.pdf(Z).shape}')  # debug
            #ei[sigma == 0.0] = 0.0  # ei = 0 if sigma=0 (mask)
            #print(f'utility.shape = {ei.shape}') # debug
            return ei.reshape(-1), mu, sigma

        def next_sample(X_virtual, utility):
            """
            Searches for the highest utility value in 'utility'
            and the corresponding samples of X_virtual and
            returns the next (suggested) sample and its index
            """
            if X_virtual.shape[0] != utility.shape[0]:
                print(f'Error: X_virtual and utility should have the same number of samples (rows)')
            # TODO: what for are the next 3 lines??
            #if X_virtual.ndim == 1:  # 1D array
            #    X_virtual = X_virtual.reshape(-1, 1)
            #c = np.c_[X_virtual, utility.reshape(-1, 1)]
            index = np.argmax(utility)

            return X_virtual[index], index

        ###################################
        #### END OF INTERNAL FUNCTIONS ####
        ###################################

        # SMART PREPROCESSING: TODO: needs testing to prove efficacy
        # REMOVE THE 33% WORST (lowest/highest target) POINTS
        # n_samples = features.shape[0]
        # if n_samples > 5:
        #     n_remove = n_samples // 3  # remove 33% of worst points from features
        #     for i in range(n_remove):
        #         if maximize:  # low-target points then must be removed
        #             index_remove = np.argmin(target)
        #         else:  # we search small targets, therefore high ones must be removed
        #             index_remove = np.argmax(target)
        #         features = np.delete(features, index_remove, axis=0)
        #         target = np.delete(target, index_remove, axis=0)

        # remove features from X_virtual
        X_virtual = clean_array(X_virtual, features)

        # - - - - - - - - - - - - - - - - - - - - - -
        # PART I: Manual BO (self-written functions)
        # - - - - - - - - - - -  - - - - - - - - - -
        target_ = target.copy()


        # 1) GP model
        if mykernel == 'matern':
            # 1a) Model 1
            kernel = ConstantKernel(constant_value=1.0, constant_value_bounds=(1e-3, 1e3)) * Matern(length_scale=1.0, length_scale_bounds=(1e-3, 1e3)) + WhiteKernel()
            model = GPR(kernel = kernel, n_restarts_optimizer=10, normalize_y=True)
        else:
            # 1b) Model 2
            sigma_f, l = 1, 1  # non-optimized hyperparameters
            kernel1 = ConstantKernel(constant_value=sigma_f,
                                     constant_value_bounds=(1e-3, 1e3))
            kernel2 = RBF(length_scale=l, length_scale_bounds=(1e-3, 1e3))
            kernel = kernel1 * kernel2 + WhiteKernel()
            model = GPR(kernel=kernel, n_restarts_optimizer=10, normalize_y=True)

        # model for qualitative estimative only (not used in the BO)
        model_estimative = GPR(kernel=kernel, n_restarts_optimizer=10, normalize_y=True)
        xscaler = StandardScaler()
        X = xscaler.fit_transform(features)
        model_estimative.fit(X, target_)
        X_virtual_s_greedy = xscaler.transform(X_virtual)
        pred_greedy = model_estimative.predict(X_virtual_s_greedy)
        if maximize:
            index5 =  np.argmax(pred_greedy)
            #pred_greed = pred_greedy[index_max]
            sample_greed = X_virtual[index5]
        else:
            index5 = np.argmin(pred_greedy)
            #pred_greed = pred_greedy[index_min]
            sample_greed = X_virtual[index5]


        # 3) Get next sample
        utility, mu, sigma = ei(model, X_virtual, features, target_, qsi=qsi)
        next_samp, index1 = next_sample(X_virtual, utility)

        # 4) Predicted target of next_samp
        # next_samp_s = xscaler.transform(next_samp.reshape(1, -1))
        # pred_target_s = model_estimative.predict(next_samp_s)
        # pred_target_new = scalery.inverse_transform(pred_target_s.reshape(-1,1))
        # pred_target = model.predict(next_samp.reshape(1, -1))
        # pred_target = scalery.inverse_transform(pred_target.reshape(-1, 1))  # 1 target property only!


        # # - - - - - - - - - - - - - - - - - - - - - -
        # # PART II: modAL library
        # # - - - - - - - - - - -  - - - - - - - - - - -

        # target_ = target.copy()

        # if not maximize:
        #     target_ = -target_

        # # preprocess Y:
        # scaleryy = StandardScaler()
        # target_ = scaleryy.fit_transform(target_.reshape(-1, 1))

        if scale_features: # target and features are preprocessed
            # preprocess X? X_virtual and features are already in the same scale, but sometimes GPR complains about convergence
            scalerx = StandardScaler()
            X_train = scalerx.fit_transform(features)
            X_virtual_s = scalerx.transform(X_virtual)
            y_train = target_.reshape(-1, 1) # target is anyway preprocessed
        else: # only the target is preprocessed
            X_train, y_train = features, target_.reshape(-1, 1)

        
        # - - - - - - - - - - - - - - - - - - - - - - - -
        # PART III: Add diversity with a random sample
        # - - - - - - - - - - - - - - - - - - - - - - - -

        index3 = random.randint(0, X_virtual.shape[0] - 1) # random.randint does not exclude the right bound limit...
        random_samp = X_virtual[index3]

    
        # - - - - - - - - - - - - - - - - - - - - - - - -
        # PART IV: AL drawing (via KRR, class Al()), for 1 target property
        # - - - - - - - - - - - - - - - - - - - - - - - -
        al = Al(features, target) # external class
        starting_dataset = np.c_[features, target.reshape(-1,1)]
        al.next_sample(virtual_features=X_virtual, starting_dataset=starting_dataset, n_best=1)
        al_sample = al.best_samples.reshape(1, -1)

     
        # - - - - - - - - - - - - - - - - - - - - -
        # Final GP predictions of the points found
        # - - - - - - - - - - - - - - - - - - - - -

        # all previous samples added here
        sample1 = next_samp.reshape(1,-1)
        # sample2 = next_samp_modal.reshape(1, -1)
        sample3 = random_samp.reshape(1, -1)
        sample4 = al_sample
        sample5 = sample_greed.reshape(1,-1)
        #              manual    random     AL     Greedy
        X_test = np.r_[sample1, sample3, sample4, sample5]
        samples = X_test.copy()

        ################################################

        # Make fast predictions using the full dataset
        if mykernel == 'rbf':
            kernel = ConstantKernel(constant_value=1.0, constant_value_bounds=(1e-3, 1e3)) * RBF(length_scale=1.0, length_scale_bounds=(1e-3, 1e3)) + WhiteKernel()
        elif mykernel == 'matern':
            kernel = ConstantKernel(constant_value=1.0, constant_value_bounds=(1e-3, 1e3)) * Matern(length_scale=1.0, length_scale_bounds=(1e-3, 1e3)) + WhiteKernel()

        fullmodel = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=10, normalize_y=True)  
        
        xscalerfull = MinMaxScaler()
        if use_best_n:
            features_full_s = xscalerfull.fit_transform(features_full)
        else:
            features_full_s = xscalerfull.fit_transform(features)
        
        X_test_s = xscalerfull.transform(X_test)
        
        fullmodel.fit(features_full_s, target_full) # targets preprocessed internally
        fullpredictions, fullstd = fullmodel.predict(X_test_s, return_std=True)
        
        # Full predictions are useful if use_best_n was used (few samples were then available!)
        if use_best_n:
            opttypes = ['Manual', 'Random', 'AL', 'Greedy']
            print(f'\nThis round was done with fewer samples (via use_best_n). Predictions using the ENTIRE dataset (kernel: {mykernel}):\n')
            for botype, sample, pred, std in zip(opttypes, X_test, fullpredictions, fullstd):
                print(f'{botype:<10}: {sample} (pred = {pred:>.3f} +/- {std:>.3f})')
                
       
        ################################################

        if mykernel == 'matern':
            # 1a) Model 1 (O Matern frequentemente fica preso e quase nao se mexe!)
            kernel = ConstantKernel(constant_value=1.0, constant_value_bounds=(1e-3, 1e3)) * Matern(length_scale=1.0, length_scale_bounds=(1e-3, 1e3)) + WhiteKernel()
        else:
            # 1b) Model 2
            sigma_f, l = 1, 1  # non-optimized hyperparameters
            kernel1 = ConstantKernel(constant_value=sigma_f,
                                     constant_value_bounds=(1e-3, 1e3))
            kernel2 = RBF(length_scale=l, length_scale_bounds=(1e-3, 1e3))
            kernel = kernel1 * kernel2 + WhiteKernel()

        gpr = GPR(kernel=kernel, n_restarts_optimizer=10, normalize_y=True)
        #gpr2 = GPR(kernel=kernel, n_restarts_optimizer=10, normalize_y=True) # for unscaled predictions

        xscaler = StandardScaler()
        X_train_s = xscaler.fit_transform(features)
        X_test_s = xscaler.transform(X_test)

        gpr.fit(X_train_s, y_train)

        predictions, stds = gpr.predict(X_test_s, return_std=True)


        # - - - - - - - - - - - - - - - - - -
        # Print results #, samples[4]
        # - - - - - - - - - - - - - - - - - -
        if not silence:

            print('\n#######################################')
            if index1 == 0:
                print(f'BO sample (manual/{mykernel}/qsi={qsi}):\n{sample1[0]}, index = {index1} (Careful !!!), GP prediction (preproc): {predictions[0]:.3f} +/- {stds[0]:.2f}\n')
            else:
                print(f'BO sample (manual/{mykernel}/qsi={qsi}):\n{sample1[0]}, index = {index1}, GP prediction (preproc): {predictions[0]:.3f} +/- {stds[0]:.2f}\n')
            print(f'Random sample:\n{sample3[0]}, index = {index3}, GP prediction (preproc): {predictions[1]:.3f} +/- {stds[1]:.2f}\n')
            print(f'AL sample (RF):\n{sample4[0]}, GP prediction (preproc): {predictions[2]:.3f} +/- {stds[2]:.2f}\n')
            print(f"Sample(greedy):\n{sample5[0]}, index = {index5}, GP prediction (preproc) = {predictions[3]:.3f} +/- {stds[3]:.2f}\n")
            print('\nALL SAMPLES (BO/manual, Random, AL, Greedy) AS A SINGLE ARRAY:\n')
            sample_ = 'np.array(['
            for i, sample in enumerate(samples):
                sample_ += '['
                for col in sample:
                    sample_ += f'{col:8.4f},'
                sample_ = sample_[:-1]  # remove the last comma
                sample_ += '],'
                if i == 0:
                    print(sample_)
                elif i != 0 and i != samples.shape[0] - 1:
                    print(f'          {sample_}')
                else:
                    sample_ = sample_[:-1] + '])'
                    print(f'          {sample_}')
                sample_ = ''

            # Evaluation of duplicated samples
            self.check_duplicates(samples) # if any sample is duplicated (inside features.npy), print a warning message     

            print('#######################################')


        return samples[0], samples[1], samples[2], samples[3]


    def update_X_virtual(self, indices):
        """
        Remove from X_virtual.npy the samples with indices given in the list 'indices', then save it back
        to the same file (assumed to be X_virtual.npy). This is useful to removed samples previously
        queried during the bayesian opt.
        """
        X = np.load('X_virtual.npy')
        Xnew = np.delete(X, indices, axis = 0)
        np.save('X_virtual', Xnew)


    def plot_bo(self, target = None, labels = None, save_fig = False, target_name=None, use_logplot=False):
        """
        Plot the evolution of the bayesian opt (+ Al + random).
        :param target: target property
        :param labels: list of strings (e.g., ['r','r','b','a','b']) corresponding to each target property. These
                labels are effectively the procedures used ('b' = bayesian opt, 'a' = Active Learning, 'r' = Random)
                to generate each experiment.
        :param save_fig: if the figure must be saved in the current folder (standard filename = bo_evolution_tag.png,
                where tag = YYYMMDD_HHmmss)
        :return: show the plot on the screen
        """
        bo_indices, al_indices, random_indices, greedy_indices = [], [], [], []
        for i, label in enumerate(labels):
            if label == 'b':
                bo_indices.append(i+1) # the number of the experiment (starts from 1)
            elif label == 'a':
                al_indices.append(i + 1)  # the number of the experiment (starts from 1)
            elif label == 'r':
                random_indices.append(i + 1)  # the number of the experiment (starts from 1)
            elif label == 'g':
                greedy_indices.append(i + 1)  # the number of the experiment (starts from 1)
            else:
                print("Labels must be either 'b' (bayesian opt), 'a' (active learning), 'r' (random) or 'g' (greedy).")
                return

        plt.figure(figsize=(8, 6))
        plt.plot([i + 1 for i in range(target.shape[0])], target, '-', color='gray', lw=3)

        if random_indices:
            random_indices = np.array(random_indices, dtype=int)
            if use_logplot:
                plt.semilogy(random_indices, target[random_indices - 1], 'ro', ms=8, label='Random')
            else:
                plt.plot(random_indices, target[random_indices - 1], 'ro', ms=8, label='Random')
        if bo_indices:
            bo_indices = np.array(bo_indices, dtype=int)
            if use_logplot:
                plt.semilogy(bo_indices, target[bo_indices - 1], 'bo', ms=8, label='Bayesian Opt')
            else:
                plt.plot(bo_indices, target[bo_indices - 1], 'bo', ms=8, label='Bayesian Opt')
        if al_indices:
            al_indices = np.array(al_indices, dtype=int)
            if use_logplot:
                plt.semilogy(al_indices, target[al_indices - 1], 'go', ms=8, label='Active Learning')
            else:
                plt.plot(al_indices, target[al_indices - 1], 'go', ms=8, label='Active Learning')
        if greedy_indices:
            greedy_indices = np.array(greedy_indices, dtype=int)
            if use_logplot:
                plt.semilogy(greedy_indices, target[greedy_indices - 1], 'co', ms=8, label='Greedy')
            else:
                plt.plot(greedy_indices, target[greedy_indices - 1], 'co', ms=8, label='Greedy')

        # X,Y labels
        plt.xlabel('Experiment #', fontsize=16, labelpad=12)
        if not target_name:
            plt.ylabel('Target property', fontsize=16, labelpad=12)
        else:
            plt.ylabel(target_name, fontsize=16, labelpad=12)

        npoints = target.shape[0]
        if npoints < 8:
            myticks = [i for i in range(1, npoints+1)]
        else:
            myticks = [i for i in range(1, npoints + 1, npoints//8)]
        plt.xticks(myticks, fontsize=13)
        plt.yticks(fontsize=13)
        plt.legend(fontsize=11, frameon=False, ncol=4, loc = 'upper left')

        # scale the plot
        ymax = target.max()
        ymin = target.min()
        delta = ymax - ymin
        if not use_logplot:
            plt.ylim(ymin - 0.06*delta, ymax + 0.13*delta)
        else:
            plt.ylim(ymin - 1.06*delta, ymax + 1.14*delta)


        if save_fig:
            timenow = datetime.datetime.now()
            filename = f"bo_evolution_" + timenow.strftime("%Y%m%d_%H%M%S") + '.png'
            plt.savefig(filename, dpi=1200)
        else:
            plt.show()


    def generate_2d_array(self, n=None, ranges_discretization=None):
        '''
        Generates an array with 'n' random combinations of 'x' parameters by specifying
        a nested list containing the start, stop and increment of each parameter, as:
        ranges_dicretization = [[start1, stop1, incr1], [start2,stop2,incr2], etc].

        duplicates are automatically removed from the generated array
        This function is useful when generatingg processing parameters obeying range limits
        and incremental values.

        How to use it:

        >>> array = generate_2d_array(n = 2500000, ranges_discretization = [(4, 8, 0.1), (110, 190, 1), (8, 13, 1), (250, 270, 2), (250, 270, 2)])

        '''
        num_rows = n
        num_columns = len(ranges_discretization)

        # Define the value ranges and step sizes for each column
        value_ranges = ranges_discretization

        # Initialize an empty array to store the generated values
        result = np.zeros((num_rows, num_columns))

        for col in range(num_columns):
            start, end, step = value_ranges[col]

            # Generate random values within the specified range and step
            random_values = np.arange(start, end + step, step)

            # Shuffle the values to randomize the order
            np.random.shuffle(random_values)

            # Fill the column by randomly sampling from available values
            result[:, col] = np.random.choice(random_values, num_rows)

        # remove the duplicates in the array
        unique_tuples = {tuple(row) for row in result}  # a set of tuples
        # Convert the unique tuples back to a NumPy array
        unique_array = np.array(list(unique_tuples), dtype=np.float32)

        return unique_array

